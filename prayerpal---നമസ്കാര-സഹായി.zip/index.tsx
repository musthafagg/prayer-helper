/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, Chat, GenerateContentResponse } from '@google/genai';
import * as marked from 'marked'; // Assuming esm.sh provides 'marked' as an object with a 'parse' method.

const GEMINI_API_KEY = process.env.API_KEY;
const MODEL_NAME = 'gemini-2.5-flash-preview-04-17';

const chatHistoryElement = document.getElementById('chat-history') as HTMLDivElement;
const messageInputElement = document.getElementById('message-input') as HTMLInputElement;
const sendButtonElement = document.getElementById('send-button') as HTMLButtonElement;
const languageSelectorElement = document.getElementById('language-selector') as HTMLSelectElement;
const appTitleElement = document.querySelector('#header-content h1') as HTMLHeadingElement;


let chat: Chat | null = null;
let isLoading = false;
let currentLanguage = 'ml'; // Default language

const SCRIPT_DIRECTION_MAP: Record<string, 'ltr' | 'rtl'> = {
  'ml': 'ltr',
  'en': 'ltr',
  'ar': 'rtl',
};


const LOCALIZED_TEXT: Record<string, Record<string, string>> = {
  ml: {
    welcome: 'നമസ്കാരം! ഇസ്ലാമിക പ്രാർത്ഥനയെക്കുറിച്ച് നിങ്ങൾക്ക് എന്തറിയണം?',
    chatError: 'ചാറ്റ് ആരംഭിക്കുന്നതിൽ പിശക് സംഭവിച്ചു.',
    sendError: 'മറുപടി ലഭിക്കുന്നതിൽ പിശക് സംഭവിച്ചു. ദയവായി വീണ്ടും ശ്രമിക്കുക.',
    inputPlaceholder: 'നിങ്ങളുടെ സംശയം ഇവിടെ ചോദിക്കൂ...',
    inputAriaLabel: 'ചോദ്യം ടൈപ്പ് ചെയ്യുക',
    sendButton: 'അയക്കൂ',
    sendButtonAriaLabel: 'അയക്കൂ',
    sendingButton: 'അയക്കുന്നു...',
    userDisplay: 'നിങ്ങൾ',
    botDisplay: 'PrayerPal',
    errorDisplay: 'Error',
    apiKeyError: 'API Key ലഭ്യമല്ല. API_KEY എൻവയോൺമെന്റ് വേരിയബിൾ സജ്ജമാക്കുക.',
    appTitle: 'PrayerPal - നമസ്കാര സഹായി'
  },
  en: {
    welcome: 'Hello! What would you like to know about Islamic prayer?',
    chatError: 'Error initializing chat.',
    sendError: 'Error getting a response. Please try again.',
    inputPlaceholder: 'Ask your question here...',
    inputAriaLabel: 'Type your question',
    sendButton: 'Send',
    sendButtonAriaLabel: 'Send',
    sendingButton: 'Sending...',
    userDisplay: 'You',
    botDisplay: 'PrayerPal',
    errorDisplay: 'Error',
    apiKeyError: 'API Key not found. Please set the API_KEY environment variable.',
    appTitle: 'PrayerPal - Prayer Helper'
  },
  ar: {
    welcome: 'مرحباً! ماذا تود أن تعرف عن الصلاة الإسلامية؟',
    chatError: 'خطأ في تهيئة المحادثة.',
    sendError: 'خطأ في الحصول على رد. يرجى المحاولة مرة أخرى.',
    inputPlaceholder: 'اطرح سؤالك هنا...',
    inputAriaLabel: 'اطرح سؤالك',
    sendButton: 'إرسال',
    sendButtonAriaLabel: 'إرسال',
    sendingButton: 'جارٍ الإرسال...',
    userDisplay: 'أنت',
    botDisplay: 'PrayerPal',
    errorDisplay: 'خطأ',
    apiKeyError: 'لم يتم العثور على مفتاح API. يرجى تعيين متغير البيئة API_KEY.',
    appTitle: 'PrayerPal - مساعد الصلاة'
  }
};

function getSystemInstruction(languageCode: string): string {
  switch (languageCode) {
    case 'en':
      return `You are an expert on Islamic prayer (Salat/Namaz). Answer questions in English. Your answers should be accurate, clear, and easy to understand. Provide information based on Islamic scriptures and scholarly opinions. Regardless of the input language, reply ONLY in English.`;
    case 'ar':
      return `أنت خبير في الصلاة الإسلامية. أجب على الأسئلة باللغة العربية. يجب أن تكون إجاباتك دقيقة وواضحة وسهلة الفهم. قدم المعلومات بناءً على النصوص الإسلامية وآراء العلماء. بغض النظر عن لغة الإدخال، قم بالرد باللغة العربية فقط.`;
    case 'ml':
    default:
      return `നിങ്ങൾ ഇസ്ലാമിക പ്രാർത്ഥനയെ (നിസ്കാരം) സംബന്ധിച്ച ചോദ്യങ്ങൾക്ക് മലയാളത്തിൽ ഉത്തരം നൽകുന്ന ഒരു വിദഗ്ദ്ധനാണ്. നിങ്ങളുടെ ഉത്തരങ്ങൾ കൃത്യവും, വ്യക്തവും, മനസ്സിലാക്കാൻ എളുപ്പമുള്ളതും ആയിരിക്കണം. ഇസ്ലാമിക ഗ്രന്ഥങ്ങളെയും പണ്ഡിതന്മാരുടെ അഭിപ്രായങ്ങളെയും അടിസ്ഥാനമാക്കി വിവരങ്ങൾ നൽകുക. ഉപയോക്താവ് മലയാളത്തിൽ ചോദിക്കുമ്പോൾ മലയാളത്തിൽ മാത്രം മറുപടി നൽകുക.`;
  }
}

function updateUIText(languageCode: string) {
  const texts = LOCALIZED_TEXT[languageCode] || LOCALIZED_TEXT.ml;
  messageInputElement.placeholder = texts.inputPlaceholder;
  messageInputElement.setAttribute('aria-label', texts.inputAriaLabel);
  sendButtonElement.textContent = texts.sendButton;
  sendButtonElement.setAttribute('aria-label', texts.sendButtonAriaLabel);

  document.documentElement.lang = languageCode;
  document.documentElement.dir = SCRIPT_DIRECTION_MAP[languageCode] || 'ltr';
  chatHistoryElement.dir = SCRIPT_DIRECTION_MAP[languageCode] || 'ltr';
  messageInputElement.dir = SCRIPT_DIRECTION_MAP[languageCode] || 'ltr';
  
  if (appTitleElement) {
    appTitleElement.textContent = texts.appTitle;
  }
  const titleTag = document.querySelector('title');
  if (titleTag) {
    titleTag.textContent = texts.appTitle;
  }
}


async function initializeChat(languageCode: string) {
  currentLanguage = languageCode;
  updateUIText(languageCode);
  chatHistoryElement.innerHTML = ''; // Clear chat history

  if (!GEMINI_API_KEY) {
    displayError(LOCALIZED_TEXT[currentLanguage].apiKeyError);
    setLoading(false); // Ensure UI is not stuck in loading state
    messageInputElement.disabled = true; // Disable input if no API Key
    sendButtonElement.disabled = true; // Disable send if no API Key
    return;
  }
  messageInputElement.disabled = false; // Re-enable if API key was found later (e.g. language change)
  sendButtonElement.disabled = false;

  try {
    const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });
    chat = ai.chats.create({
      model: MODEL_NAME,
      config: {
        systemInstruction: getSystemInstruction(languageCode),
      },
    });
    displayMessage(LOCALIZED_TEXT[currentLanguage].botDisplay, LOCALIZED_TEXT[currentLanguage].welcome, 'bot-message', true); // Welcome message can be markdown
  } catch (error) {
    console.error('Chat initialization error:', error);
    displayError(LOCALIZED_TEXT[currentLanguage].chatError);
  }
}

function displayMessage(senderKey: string, message: string, cssClass: string, isMarkdown = false) {
  const messageElement = document.createElement('div');
  messageElement.classList.add('message', cssClass);
  messageElement.dir = SCRIPT_DIRECTION_MAP[currentLanguage] || 'ltr';


  const senderElement = document.createElement('strong');
  senderElement.textContent = senderKey;
  messageElement.appendChild(senderElement);

  const contentElement = document.createElement('div');
  if (isMarkdown) {
    // It's crucial that DOMPurify.sanitize is robust.
    const rawHtml = marked.parse(message) as string; // marked.parse can return string or Promise<string>
    contentElement.innerHTML = DOMPurify.sanitize(rawHtml);
  } else {
    contentElement.textContent = message;
  }
  messageElement.appendChild(contentElement);

  chatHistoryElement.appendChild(messageElement);
  chatHistoryElement.scrollTop = chatHistoryElement.scrollHeight;
}

function displayError(errorMessage: string) {
  displayMessage(LOCALIZED_TEXT[currentLanguage].errorDisplay, errorMessage, 'error-message');
}

function setLoading(loading: boolean) {
  isLoading = loading;
  messageInputElement.disabled = loading;
  sendButtonElement.disabled = loading;
  const texts = LOCALIZED_TEXT[currentLanguage] || LOCALIZED_TEXT.ml;
  sendButtonElement.textContent = loading ? texts.sendingButton : texts.sendButton;
}

async function sendMessage() {
  if (!chat || isLoading) return;

  const messageText = messageInputElement.value.trim();
  if (!messageText) return;

  displayMessage(LOCALIZED_TEXT[currentLanguage].userDisplay, messageText, 'user-message');
  messageInputElement.value = '';
  setLoading(true);

  let botMessageElement: HTMLDivElement | null = null;
  let accumulatedResponse = "";

  try {
    const responseStream = await chat.sendMessageStream({ message: messageText });

    // Create container for bot message once
    const botMessageContainer = document.createElement('div');
    botMessageContainer.classList.add('message', 'bot-message');
    botMessageContainer.dir = SCRIPT_DIRECTION_MAP[currentLanguage] || 'ltr';

    const senderElement = document.createElement('strong');
    senderElement.textContent = LOCALIZED_TEXT[currentLanguage].botDisplay;
    botMessageContainer.appendChild(senderElement);
    
    const contentElement = document.createElement('div'); // Content will be updated here
    botMessageContainer.appendChild(contentElement);
    chatHistoryElement.appendChild(botMessageContainer);
    botMessageElement = botMessageContainer;

    for await (const chunk of responseStream) {
      accumulatedResponse += chunk.text;
      // Sanitize HTML from markdown to prevent XSS.
      // marked.parse should ideally handle incremental updates better, but re-parsing
      // the accumulated string is a common approach for simplicity.
      const sanitizedHtml = DOMPurify.sanitize(marked.parse(accumulatedResponse) as string);
      contentElement.innerHTML = sanitizedHtml;
      chatHistoryElement.scrollTop = chatHistoryElement.scrollHeight;
    }
  } catch (error) {
    console.error('Send message error:', error);
     if (botMessageElement && botMessageElement.parentElement) { 
       chatHistoryElement.removeChild(botMessageElement); // Remove partially streamed message on error
    }
    displayError(LOCALIZED_TEXT[currentLanguage].sendError);
  } finally {
    setLoading(false);
  }
}

// Custom DOMPurify mock - enhanced for better security but not a replacement for a dedicated library.
const DOMPurify = {
  sanitize: (htmlString: string): string => {
    if (typeof htmlString !== 'string') return ''; 

    const temp = document.createElement('div');
    temp.innerHTML = htmlString;

    // Remove potentially harmful tags
    const DANGEROUS_TAGS = ['script', 'style', 'iframe', 'object', 'embed', 'form', 'link', 'meta'];
    DANGEROUS_TAGS.forEach(tagName => {
      const tags = temp.getElementsByTagName(tagName);
      while (tags.length > 0) {
        tags[0]?.parentNode?.removeChild(tags[0]);
      }
    });

    const allElements = temp.getElementsByTagName('*');
    for (let i = 0; i < allElements.length; i++) {
      const el = allElements[i] as HTMLElement;

      // Remove on* event handlers
      for (const attr of Array.from(el.attributes)) {
        if (attr.name.toLowerCase().startsWith('on')) {
          el.removeAttribute(attr.name);
        }
      }

      // Sanitize URL attributes
      const URL_ATTRIBUTES = ['href', 'src', 'data', 'formaction', 'background', 'cite', 'longdesc'];
      URL_ATTRIBUTES.forEach(attrName => {
        if (el.hasAttribute(attrName)) {
          const val = el.getAttribute(attrName)?.trim().toLowerCase() || '';
          if (val.startsWith('javascript:') || val.startsWith('data:text/html') || val.startsWith('vbscript:')) {
            el.removeAttribute(attrName);
          }
        }
      });

      // Secure <a> tags
      if (el.tagName === 'A') {
        if (el.hasAttribute('href')) {
          el.setAttribute('target', '_blank'); 
          el.setAttribute('rel', 'noopener noreferrer');
        } else {
          // Anchor tag without href, could be used for JS.
          // Optionally, replace with span or remove. For now, it's benign without href.
        }
      }
    }
    return temp.innerHTML;
  }
};

// Event Listeners
sendButtonElement.addEventListener('click', sendMessage);
messageInputElement.addEventListener('keypress', (event) => {
  if (event.key === 'Enter' && !event.shiftKey) { 
    event.preventDefault(); 
    sendMessage();
  }
});

languageSelectorElement.addEventListener('change', (event) => {
  const newLanguage = (event.target as HTMLSelectElement).value;
  initializeChat(newLanguage);
});

// Initial load
initializeChat(currentLanguage);
